---
name: Velocity Logistics
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#4c4546'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#7e7576'
  outline-variant: '#cfc4c5'
  surface-tint: '#5e5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1b1b1b'
  on-primary-container: '#848484'
  inverse-primary: '#c6c6c6'
  secondary: '#b71519'
  on-secondary: '#ffffff'
  secondary-container: '#db332f'
  on-secondary-container: '#fffbff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#2a1700'
  on-tertiary-container: '#b87500'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c6'
  on-primary-fixed: '#1b1b1b'
  on-primary-fixed-variant: '#474747'
  secondary-fixed: '#ffdad6'
  secondary-fixed-dim: '#ffb4ab'
  on-secondary-fixed: '#410002'
  on-secondary-fixed-variant: '#93000c'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  data-mono:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  container-padding: 16px
  stack-gap: 12px
  touch-target-min: 48px
  gutter: 16px
---

## Brand & Style

The design system is centered on **high-velocity reliability**. It targets professional couriers who operate in fast-paced, high-stress urban environments. The emotional response must be one of absolute precision, command, and immediate clarity.

The visual style is **Corporate Modern with a Functional Edge**. It prioritizes utility and speed of recognition over decorative elements. By utilizing stark black foundations and aggressive action colors, the UI remains legible even when the device is mounted on a vehicle or held in one hand during transit. The aesthetic is clean, systematic, and evokes a sense of technological precision and industrial speed.

## Colors

This design system utilizes a high-contrast palette to drive decision-making:

- **Primary (Pure Black):** Used for structural elements, headers, and primary navigation to establish a foundation of trust and professional stability.
- **Secondary (Signal Red):** Reserved exclusively for high-priority "Action" triggers, active delivery states, and primary "Accept" buttons to ensure immediate visibility.
- **Tertiary (Amber):** Dedicated to alerts, time-sensitive warnings, and pending statuses that require courier attention.
- **Surface & Backgrounds:** Uses a range of cool grays (`#F8FAFC` to `#94A3B8`) to maintain a clean environment that makes the action colors pop.

## Typography

The design system uses **Inter** for its exceptional legibility and neutral, modern tone. To ensure the courier can read critical information at a glance while in motion, font sizes are slightly oversized compared to standard consumer apps.

- **Headlines:** Bold and tight for quick scanning of delivery addresses or earnings.
- **Labels:** Used for metadata like "Distance" or "Estimated Time."
- **Data Mono:** For order IDs and tracking numbers, a monospaced alternative (Geist) is used to prevent character confusion.
- **Mobile Scale:** On mobile devices, `headline-lg` is capped at 24px to ensure content density remains high without sacrificing readability.

## Layout & Spacing

The layout follows a **Fluid Grid** model optimized for one-handed mobile use. 

- **Margins:** A consistent 16px lateral margin is applied to all screens.
- **Interactive Zones:** All primary action buttons must maintain a minimum height of 56px to accommodate gloved hands or rapid tapping.
- **Vertical Rhythm:** A 4px baseline grid ensures alignment, but components are primarily spaced using 12px and 24px increments to create clear logical groupings of delivery data.
- **Safe Areas:** Critical UI elements (like "Slide to Complete") must respect bottom safe-area insets to avoid accidental system gestures.

## Elevation & Depth

Visual hierarchy is established through **Ambient Shadows** and **Tonal Layering**:

- **Level 0 (Background):** Neutral light gray (`#F8FAFC`).
- **Level 1 (Cards):** White surfaces with a very soft, diffused shadow (10% opacity, 8px blur, 4px Y-offset) to lift content from the background.
- **Level 2 (Active States):** Increased shadow spread and a slight border (1px) in the primary black color to indicate focus or "Active Task" status.
- **Transitions:** Use subtle depth shifts to indicate that a delivery card has been "picked up" or expanded.

## Shapes

The design system utilizes **Rounded** geometry (0.5rem / 8px) to soften the industrial nature of the app while maintaining a professional look. 

- **Standard Elements:** 8px radius for input fields and standard buttons.
- **Cards & Containers:** 16px (rounded-lg) for main delivery cards to create a distinct, approachable container.
- **Status Indicators:** Pill-shapes (full round) for chips and badges to distinguish them from interactive buttons.

## Components

- **Action Buttons:** Large, full-width buttons. Primary actions use the Secondary Red for "Accept" or "Confirm." Destructive actions or "Decline" use low-contrast gray outlines.
- **Delivery Cards:** The core component. Must feature a clear visual hierarchy: Address (Headline-MD), Time/Distance (Label-LG with icons), and Earnings (Headline-MD in the primary palette).
- **Status Chips:** Small, pill-shaped indicators for "Express," "Fragile," or "High Value."
- **Progress Steppers:** Vertical lines with nodes to show the journey (Pickup -> In Transit -> Drop off).
- **Map Interaction:** Floating Action Buttons (FABs) for "Recenter" and "Toggle Traffic" using the Primary Black color.
- **Input Fields:** Large tap targets with clear labels, specifically optimized for numeric entry (OTP codes) and quick-search of locations.